package com.creatix.fracassalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra("alarmId", -1)
        val alarm = AlarmRepository.find(context, alarmId)
        val soundType = alarm?.soundType ?: intent.getIntExtra("soundType", 0)
        val label = alarm?.label ?: intent.getStringExtra("label") ?: "Fracass'Alarm"

        val serviceIntent = Intent(context, AlarmPlayerService::class.java).apply {
            action = AlarmPlayerService.ACTION_START
            putExtra("alarmId", alarmId)
            putExtra("soundType", soundType)
            putExtra("label", label)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }

        val activityIntent = Intent(context, AlarmRingingActivity::class.java).apply {
            putExtra("alarmId", alarmId)
            putExtra("soundType", soundType)
            putExtra("label", label)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        context.startActivity(activityIntent)

        // Réarme pour le lendemain si l'alarme existe encore et reste activée.
        if (alarm != null && alarm.enabled) {
            AlarmScheduler.schedule(context, alarm)
        }
    }
}
