package com.creatix.fracassalarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AlarmRepository {
    private const val PREFS = "fracass_alarm_prefs"
    private const val KEY_ALARMS = "alarms_json_v1"

    fun load(context: Context): MutableList<AlarmItem> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_ALARMS, null)
        if (raw.isNullOrBlank()) {
            val defaults = createDefaultAlarms()
            save(context, defaults)
            return defaults.toMutableList()
        }

        return runCatching {
            val arr = JSONArray(raw)
            val list = mutableListOf<AlarmItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    AlarmItem(
                        id = o.getInt("id"),
                        hour = o.getInt("hour"),
                        minute = o.getInt("minute"),
                        label = o.optString("label", "Alarme"),
                        enabled = o.optBoolean("enabled", false),
                        soundType = o.optInt("soundType", i % SoundBank.names.size),
                        custom = o.optBoolean("custom", false)
                    )
                )
            }
            list.sortedWith(compareBy<AlarmItem> { it.hour }.thenBy { it.minute }.thenBy { it.id }).toMutableList()
        }.getOrElse {
            val defaults = createDefaultAlarms()
            save(context, defaults)
            defaults.toMutableList()
        }
    }

    fun save(context: Context, alarms: List<AlarmItem>) {
        val arr = JSONArray()
        alarms.sortedWith(compareBy<AlarmItem> { it.hour }.thenBy { it.minute }.thenBy { it.id }).forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id)
                put("hour", a.hour)
                put("minute", a.minute)
                put("label", a.label)
                put("enabled", a.enabled)
                put("soundType", a.soundType)
                put("custom", a.custom)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ALARMS, arr.toString())
            .apply()
    }

    fun update(context: Context, updated: AlarmItem) {
        val alarms = load(context).map { if (it.id == updated.id) updated else it }
        save(context, alarms)
    }

    fun add(context: Context, hour: Int, minute: Int, label: String, soundType: Int) {
        val alarms = load(context)
        val id = ((System.currentTimeMillis() / 1000L).toInt() and 0x7fffffff)
        alarms.add(
            AlarmItem(
                id = id,
                hour = hour,
                minute = minute,
                label = label,
                enabled = true,
                soundType = soundType,
                custom = true
            )
        )
        save(context, alarms)
        AlarmScheduler.schedule(context, alarms.last())
    }

    fun delete(context: Context, id: Int) {
        val alarms = load(context)
        val target = alarms.firstOrNull { it.id == id }
        if (target != null) AlarmScheduler.cancel(context, target)
        save(context, alarms.filterNot { it.id == id })
    }

    fun find(context: Context, id: Int): AlarmItem? = load(context).firstOrNull { it.id == id }

    fun rescheduleAll(context: Context) {
        load(context).forEach { alarm ->
            if (alarm.enabled) AlarmScheduler.schedule(context, alarm) else AlarmScheduler.cancel(context, alarm)
        }
    }

    private fun createDefaultAlarms(): List<AlarmItem> {
        val result = mutableListOf<AlarmItem>()
        var id = 7000
        var soundIndex = 0
        for (h in 7..11) {
            for (m in 0..55 step 5) {
                if (h == 11 && m > 0) break
                val soundType = soundIndex % SoundBank.names.size
                result.add(
                    AlarmItem(
                        id = id++,
                        hour = h,
                        minute = m,
                        label = "Réveil brutal ${"%02d:%02d".format(h, m)}",
                        enabled = false,
                        soundType = soundType,
                        custom = false
                    )
                )
                // Rotation volontairement non linéaire pour éviter 2 familles identiques proches.
                soundIndex += 3
            }
        }
        return result
    }
}
