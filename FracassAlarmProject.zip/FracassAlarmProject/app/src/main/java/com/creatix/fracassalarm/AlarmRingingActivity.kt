package com.creatix.fracassalarm

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.app.Activity

class AlarmRingingActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var holdButton: Button
    private var holdStart = 0L
    private var alarmId = -1
    private var soundType = 0
    private var label = "Fracass'Alarm"
    private val flashColors = intArrayOf(
        Color.WHITE,
        Color.rgb(255, 0, 48),
        Color.rgb(0, 229, 255),
        Color.rgb(255, 230, 0),
        Color.rgb(255, 90, 0),
        Color.rgb(5, 3, 8)
    )
    private var colorIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId = intent.getIntExtra("alarmId", -1)
        soundType = intent.getIntExtra("soundType", 0)
        label = intent.getStringExtra("label") ?: "Fracass'Alarm"

        setupLockScreenVisibility()
        startService(Intent(this, AlarmPlayerService::class.java).apply {
            action = AlarmPlayerService.ACTION_START
            putExtra("alarmId", alarmId)
            putExtra("soundType", soundType)
            putExtra("label", label)
        })
        buildUi()
        startFlashLoop()
    }

    private fun setupLockScreenVisibility() {
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguard.requestDismissKeyguard(this, null)
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(255, 0, 48))
        }

        val title = TextView(this).apply {
            text = "RÉVEIL BRUTAL"
            textSize = 42f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val app = TextView(this).apply {
            text = "Fracass'Alarm"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val subtitle = TextView(this).apply {
            text = "$label\n${SoundBank.name(soundType)}"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 36)
        }

        val warning = TextView(this).apply {
            text = "Maintiens STOP 5 secondes pour couper."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        holdButton = Button(this).apply {
            text = "MAINTENIR STOP"
            textSize = 24f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(5, 3, 8))
            setPadding(28, 28, 28, 28)
        }

        holdButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    holdStart = System.currentTimeMillis()
                    holdButton.text = "NE LÂCHE PAS..."
                    handler.post(holdCheck)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    holdStart = 0L
                    holdButton.text = "MAINTENIR STOP"
                    true
                }
                else -> true
            }
        }

        val signature = TextView(this).apply {
            text = "cr3@tix dev'"
            textSize = 11f
            setTextColor(Color.WHITE)
            alpha = 0.72f
            gravity = Gravity.CENTER
            setPadding(0, 34, 0, 0)
        }

        root.addView(title)
        root.addView(app)
        root.addView(subtitle)
        root.addView(warning)
        root.addView(holdButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        root.addView(signature)
        setContentView(root)
    }

    private val holdCheck = object : Runnable {
        override fun run() {
            if (holdStart > 0L) {
                val elapsed = System.currentTimeMillis() - holdStart
                val remaining = (5000L - elapsed).coerceAtLeast(0L)
                holdButton.text = "STOP DANS ${remaining / 1000 + 1}s"
                if (elapsed >= 5000L) {
                    stopAlarm()
                } else {
                    handler.postDelayed(this, 200)
                }
            }
        }
    }

    private fun startFlashLoop() {
        handler.post(object : Runnable {
            override fun run() {
                root.setBackgroundColor(flashColors[colorIndex % flashColors.size])
                colorIndex++
                handler.postDelayed(this, 360L)
            }
        })
    }

    private fun stopAlarm() {
        startService(Intent(this, AlarmPlayerService::class.java).apply { action = AlarmPlayerService.ACTION_STOP })
        finishAndRemoveTask()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
