package com.creatix.fracassalarm

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class BrutalSoundEngine(
    private val soundType: Int,
    private val onLevel: () -> Boolean
) {
    @Volatile private var running = false
    private var audioTrack: AudioTrack? = null
    private var worker: Thread? = null

    fun start() {
        if (running) return
        running = true
        worker = thread(name = "FracassSoundEngine") {
            val sampleRate = 44100
            val bufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(sampleRate / 2)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack = track
            track.setVolume(1.0f)
            track.play()

            val samples = ShortArray(2048)
            var frame = 0L
            while (running && onLevel()) {
                for (i in samples.indices) {
                    val t = frame.toDouble() / sampleRate.toDouble()
                    val value = pattern(soundType, t, frame, sampleRate)
                    samples[i] = (value.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
                    frame++
                }
                track.write(samples, 0, samples.size)
            }

            runCatching { track.stop() }
            runCatching { track.release() }
        }
    }

    fun stop() {
        running = false
        runCatching { audioTrack?.pause() }
        runCatching { audioTrack?.flush() }
        runCatching { audioTrack?.stop() }
        runCatching { audioTrack?.release() }
        audioTrack = null
    }

    private fun pattern(type: Int, t: Double, frame: Long, sampleRate: Int): Double {
        return when (Math.floorMod(type, SoundBank.names.size)) {
            0 -> industrialBuzzer(t)
            1 -> hospitalPanic(t)
            2 -> chaosSiren(t)
            3 -> electricShock(t, frame)
            4 -> fireAlert(t)
            5 -> metalHammer(t, frame, sampleRate)
            6 -> whiteNoiseBurst(t)
            else -> lowHighPulse(t)
        }
    }

    private fun square(freq: Double, t: Double): Double = if (sin(2.0 * PI * freq * t) >= 0.0) 1.0 else -1.0
    private fun sine(freq: Double, t: Double): Double = sin(2.0 * PI * freq * t)

    private fun industrialBuzzer(t: Double): Double {
        val gate = if ((t * 7).toInt() % 2 == 0) 1.0 else 0.25
        return 0.78 * gate * (0.65 * square(520.0, t) + 0.35 * square(1040.0, t))
    }

    private fun hospitalPanic(t: Double): Double {
        val pulse = ((t * 12).toInt() % 2 == 0)
        return if (pulse) 0.92 * square(880.0 + 80.0 * square(3.0, t), t) else 0.0
    }

    private fun chaosSiren(t: Double): Double {
        val segment = (t * 6).toInt()
        val freq = 430.0 + ((segment * 173) % 850) + 120.0 * sine(2.3, t)
        return 0.88 * (0.7 * sine(freq, t) + 0.3 * square(freq * 1.5, t))
    }

    private fun electricShock(t: Double, frame: Long): Double {
        val burst = ((t * 18).toInt() % 3 != 1)
        val noise = Random(frame xor 0xC0FFEEL).nextDouble(-1.0, 1.0)
        return if (burst) 0.86 * (0.45 * noise + 0.55 * square(1300.0 + 240.0 * sine(9.0, t), t)) else 0.0
    }

    private fun fireAlert(t: Double): Double {
        val alternate = if ((t * 2).toInt() % 2 == 0) 700.0 else 1150.0
        return 0.9 * square(alternate, t)
    }

    private fun metalHammer(t: Double, frame: Long, sampleRate: Int): Double {
        val period = sampleRate / 4
        val inHit = (frame % period) < sampleRate / 35
        val ring = sine(1540.0, t) * kotlin.math.exp(-((frame % period).toDouble() / (sampleRate / 40.0)))
        return if (inHit) 0.95 * ring + 0.35 * square(310.0, t) else 0.2 * square(155.0, t)
    }

    private fun whiteNoiseBurst(t: Double): Double {
        val burst = ((t * 5).toInt() % 2 == 0)
        val seed = (t * 44100).toLong()
        val noise = Random(seed).nextDouble(-1.0, 1.0)
        return if (burst) 0.95 * noise else 0.2 * square(520.0, t)
    }

    private fun lowHighPulse(t: Double): Double {
        val pulse = if ((t * 8).toInt() % 2 == 0) 1.0 else 0.35
        return pulse * (0.52 * square(180.0, t) + 0.48 * square(1760.0, t))
    }
}
