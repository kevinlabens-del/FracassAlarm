package com.creatix.fracassalarm

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var listContainer: LinearLayout
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        ensureNotificationPermission()
        AlarmRepository.rescheduleAll(this)
        renderAlarms()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 42)
            setBackgroundColor(Color.rgb(5, 3, 8))
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "Fracass'Alarm"
            textSize = 36f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val sig = TextView(this).apply {
            text = "cr3@tix dev'"
            textSize = 12f
            setTextColor(Color.rgb(0, 229, 255))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        val desc = TextView(this).apply {
            text = "Réveil extrême : alarmes 7h-11h, sons brutaux, flashs écran, vibration, plein volume interne."
            textSize = 15f
            setTextColor(Color.rgb(220, 220, 230))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        root.addView(title)
        root.addView(sig)
        root.addView(desc)

        root.addView(actionButton("🌙 Mode bonne nuit / vérifications") { openSettingsHelp() })
        root.addView(actionButton("➕ Ajouter une alarme") { openAddAlarm() })
        root.addView(actionButton("🔊 Tester une alarme brutale") { testAlarm() })
        root.addView(actionButton("🔄 Réarmer toutes les alarmes actives") {
            AlarmRepository.rescheduleAll(this)
            toast("Alarmes actives réarmées")
        })

        val section = TextView(this).apply {
            text = "Alarmes préchargées"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 28, 0, 12)
        }
        root.addView(section)

        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(listContainer)
        setContentView(scroll)
    }

    private fun actionButton(text: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(120, 0, 255))
            setPadding(16, 18, 16, 18)
            setOnClickListener { onClick() }
        }
    }

    private fun renderAlarms() {
        listContainer.removeAllViews()
        val alarms = AlarmRepository.load(this)
        alarms.forEach { alarm ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 18, 20, 18)
                setBackgroundColor(Color.rgb(16, 12, 25))
            }

            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val info = TextView(this).apply {
                text = "${alarm.timeText}  •  ${alarm.label}\n${SoundBank.name(alarm.soundType)}${if (alarm.custom) "  •  perso" else ""}"
                textSize = 16f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val sw = Switch(this).apply {
                isChecked = alarm.enabled
                setTextColor(Color.WHITE)
                setOnCheckedChangeListener { _, checked ->
                    val updated = alarm.copy(enabled = checked)
                    AlarmRepository.update(this@MainActivity, updated)
                    if (checked) {
                        AlarmScheduler.schedule(this@MainActivity, updated)
                        toast("${alarm.timeText} activée")
                    } else {
                        AlarmScheduler.cancel(this@MainActivity, updated)
                        toast("${alarm.timeText} désactivée")
                    }
                    renderAlarms()
                }
            }

            top.addView(info)
            top.addView(sw)
            row.addView(top)

            val buttons = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                setPadding(0, 8, 0, 0)
            }

            val test = smallButton("Test") {
                startActivity(Intent(this, AlarmRingingActivity::class.java).apply {
                    putExtra("alarmId", alarm.id)
                    putExtra("soundType", alarm.soundType)
                    putExtra("label", alarm.label)
                })
            }
            buttons.addView(test)

            if (alarm.custom) {
                val del = smallButton("Supprimer") {
                    AlarmRepository.delete(this, alarm.id)
                    renderAlarms()
                }
                buttons.addView(del)
            }

            row.addView(buttons)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, 12) }
            listContainer.addView(row, params)
        }
    }

    private fun smallButton(text: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(255, 0, 72))
            setOnClickListener { onClick() }
        }
    }

    private fun openAddAlarm() {
        val nowHour = 7
        val nowMinute = 0
        TimePickerDialog(this, { _, hour, minute ->
            chooseSoundAndLabel(hour, minute)
        }, nowHour, nowMinute, true).show()
    }

    private fun chooseSoundAndLabel(hour: Int, minute: Int) {
        val input = EditText(this).apply {
            hint = "Nom de l'alarme"
            setText("Alarme perso ${"%02d:%02d".format(hour, minute)}")
        }
        AlertDialog.Builder(this)
            .setTitle("Nom de l'alarme")
            .setView(input)
            .setPositiveButton("Suite") { _, _ ->
                val label = input.text.toString().ifBlank { "Alarme perso" }
                AlertDialog.Builder(this)
                    .setTitle("Choisis le son brutal")
                    .setItems(SoundBank.names.toTypedArray()) { _, which ->
                        AlarmRepository.add(this, hour, minute, label, which)
                        renderAlarms()
                        toast("Alarme ajoutée et activée")
                    }
                    .show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun testAlarm() {
        startActivity(Intent(this, AlarmRingingActivity::class.java).apply {
            putExtra("alarmId", -1)
            putExtra("soundType", 2)
            putExtra("label", "Test brutal")
        })
    }

    private fun openSettingsHelp() {
        AlertDialog.Builder(this)
            .setTitle("Mode bonne nuit")
            .setMessage(
                "Avant de dormir :\n\n" +
                        "1. Mets le téléphone en charge.\n" +
                        "2. Monte le volume alarme.\n" +
                        "3. Autorise les notifications.\n" +
                        "4. Désactive l'optimisation batterie pour Fracass'Alarm.\n" +
                        "5. Active les alarmes utiles.\n\n" +
                        "L'appli utilise des alarmes système exactes, notification plein écran, son alarme, vibration et écran verrouillé."
            )
            .setPositiveButton("Ouvrir réglages appli") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                })
            }
            .setNegativeButton("OK", null)
            .show()
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 120)
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
