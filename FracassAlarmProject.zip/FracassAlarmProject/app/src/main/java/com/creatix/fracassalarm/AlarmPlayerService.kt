package com.creatix.fracassalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class AlarmPlayerService : Service() {
    companion object {
        const val ACTION_START = "com.creatix.fracassalarm.START"
        const val ACTION_STOP = "com.creatix.fracassalarm.STOP"
        private const val CHANNEL_ID = "fracass_alarm_extreme_channel"
        private const val NOTIFICATION_ID = 777
    }

    private var engine: BrutalSoundEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }
            else -> {
                val alarmId = intent?.getIntExtra("alarmId", -1) ?: -1
                val soundType = intent?.getIntExtra("soundType", 0) ?: 0
                val label = intent?.getStringExtra("label") ?: "Fracass'Alarm"
                forceAlarmVolume()
                startForeground(NOTIFICATION_ID, buildNotification(alarmId, soundType, label))
                startSound(soundType)
                startVibration()
                return START_STICKY
            }
        }
    }

    private fun startSound(soundType: Int) {
        engine?.stop()
        engine = BrutalSoundEngine(soundType) { true }.also { it.start() }
    }

    private fun startVibration() {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 900, 180, 900, 180, 1600, 240)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopEverything() {
        engine?.stop()
        engine = null
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator?.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun forceAlarmVolume() {
        runCatching {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            audio.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
        }
    }

    private fun buildNotification(alarmId: Int, soundType: Int, label: String): Notification {
        val fullScreenIntent = PendingIntent.getActivity(
            this,
            alarmId + 200000,
            Intent(this, AlarmRingingActivity::class.java).apply {
                putExtra("alarmId", alarmId)
                putExtra("soundType", soundType)
                putExtra("label", label)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            alarmId + 300000,
            Intent(this, AlarmPlayerService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Fracass'Alarm sonne")
            .setContentText(label)
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(fullScreenIntent, true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP", stopIntent)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Fracass'Alarm extrême",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Canal prioritaire pour alarmes brutales plein écran"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setBypassDnd(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }
}
