package com.creatix.fracassalarm

data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String,
    val enabled: Boolean,
    val soundType: Int,
    val custom: Boolean
) {
    val timeText: String get() = "%02d:%02d".format(hour, minute)
}

object SoundBank {
    val names = listOf(
        "Buzzer industriel",
        "Panic hôpital",
        "Sirène chaos",
        "Choc électrique",
        "Alerte incendie",
        "Marteau métal",
        "Bruit blanc rafale",
        "Pulse grave/aigu"
    )

    fun name(index: Int): String = names[Math.floorMod(index, names.size)]
}
