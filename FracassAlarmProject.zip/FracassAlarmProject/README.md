# Fracass'Alarm — cr3@tix dev'

APK Android native de réveil extrême V1.

## Fonctions V1

- Alarmes préchargées de 07:00 à 11:00 toutes les 5 minutes.
- Activation/désactivation de chaque alarme.
- Ajout d'alarmes personnalisées.
- Sons synthétiques brutaux intégrés, sans fichiers MP3.
- Démarrage immédiat à pleine puissance interne de l'application.
- Tentative de mise du volume `STREAM_ALARM` au maximum.
- Notification plein écran.
- Affichage sur écran verrouillé.
- Écran maintenu allumé pendant l'alarme.
- Flashs visuels contrôlés.
- Vibration répétée.
- Bouton STOP à maintenir 5 secondes.
- Réarmement après redémarrage du téléphone.
- Workflow GitHub Actions pour générer l'APK debug.

## Compiler avec GitHub

1. Créer un dépôt GitHub.
2. Envoyer tout le contenu de ce dossier dans le dépôt.
3. Aller dans l'onglet **Actions**.
4. Lancer **Build Fracass'Alarm APK**.
5. Télécharger l'artefact **FracassAlarm-debug-apk**.

## Fichier APK généré

Après build GitHub Actions :

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Réglages Android conseillés

Pour une fiabilité maximum :

- Autoriser les notifications.
- Autoriser l'affichage plein écran si Android le demande.
- Désactiver l'optimisation batterie pour l'application.
- Monter le volume d'alarme.
- Garder le téléphone chargé.

## Note importante

La V1 est pensée pour un usage personnel/test. Les sons et flashs sont volontairement agressifs. Ne pas utiliser près d'une personne sensible aux flashs lumineux ou aux sons forts.
